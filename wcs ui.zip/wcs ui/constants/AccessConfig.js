const ManageEquipment = "Manage Equipment";
const BalanceLabour = "Balance Labour";
const ManageOrder = "Manage Order";
const Dashboard = "Dashboard";
const Report = "Report";
const Exceptions = "Exceptions";
const ManageInventory = "Manage Inventory";
const WorkMonitoring = "Work Monitoring";

export default {ManageEquipment, BalanceLabour,
				ManageOrder, Dashboard,
				Report, Exceptions,
				ManageInventory, WorkMonitoring}