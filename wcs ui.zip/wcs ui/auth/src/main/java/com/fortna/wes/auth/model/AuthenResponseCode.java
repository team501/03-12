package com.fortna.wes.auth.model;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class AuthenResponseCode {

    public static final long AUTHEN_SUCCESS = 0;
    public static final long AUTHEN_FAILURE = 1;

    private AuthenResponseCode() {
    }
}
