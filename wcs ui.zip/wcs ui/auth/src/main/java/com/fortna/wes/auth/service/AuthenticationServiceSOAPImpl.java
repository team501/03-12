package com.fortna.wes.auth.service;

import com.fortna.wcs.security.service.LoginBadgeReturn;
import com.fortna.wcs.security.service.LoginReturn;
import com.fortna.wcs.security.service.WCSSecurity;
import com.fortna.wes.auth.connector.WCSSecurityConnector;
import com.fortna.wes.auth.model.AuthenResponseData;

import javax.net.ssl.*;
import java.security.cert.CertificateException;
import java.util.Objects;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class AuthenticationServiceSOAPImpl implements AuthenticationService {

    private WCSSecurity securityService;
    private String wcsSecurityUrl;
    private String wcsSecurityContext;

    public AuthenticationServiceSOAPImpl(String wcsSecurityUrl) {
        this(wcsSecurityUrl, WCSSecurityConnector.LoginContext.PPP_CONTEXT.name());
    }

    public AuthenticationServiceSOAPImpl(String wcsSecurityUrl, String wcsSecurityContext) {
        Objects.requireNonNull(wcsSecurityUrl);
        this.wcsSecurityUrl = wcsSecurityUrl;
        this.wcsSecurityContext = wcsSecurityContext;
    }

    @Override
    public AuthenResponseData login(String username, String password) {
        LoginReturn result = getSecurityService().loginForContext(username, password, this.wcsSecurityContext);
        return convert2AuthenResponseData(result);
    }

    @Override
    public AuthenResponseData loginBadge(String badge) {
        LoginBadgeReturn result = getSecurityService().loginBadgeForContext(badge, this.wcsSecurityContext);
        return convert2AuthenResponseData(result);
    }

    @Override
    public AuthenResponseData logout(String username) {
        LoginReturn loginResult = getSecurityService().logoutForContext(username, this.wcsSecurityContext);
        return convert2AuthenResponseData(loginResult);
    }

    @Override
    public AuthenResponseData logoutBadge(String badge) {
        LoginBadgeReturn loginResult = getSecurityService().logoutBadgeForContext(badge, this.wcsSecurityContext);
        return convert2AuthenResponseData(loginResult);
    }

    protected WCSSecurity getSecurityService() {
        if (securityService == null) {
            securityService = WCSSecurityConnector.getWCSSecurityService(wcsSecurityUrl);
        }
        return securityService;
    }

    static {
        disableSSLVerification();
    }

    private static void disableSSLVerification() {

        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }

            @Override
            public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
                    throws CertificateException {
            }

            @Override
            public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
                    throws CertificateException {
            }

        }};

        SSLContext sc = null;
        try {
            sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
        } catch (Exception e) {
        }
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
    }
}
