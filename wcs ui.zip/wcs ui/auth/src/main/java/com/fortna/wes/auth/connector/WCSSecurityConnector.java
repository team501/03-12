/*
 *  Copyright 2017 Fortna, Inc.
 */
package com.fortna.wes.auth.connector;

import com.fortna.wcs.security.service.WCSSecurity;
import com.fortna.wcs.security.service.WCSSecurityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import java.net.URL;

/**
 *
 * @author Tho Nguyen <thonguyen@fortna.com>
 */
public class WCSSecurityConnector {

    private static final Logger LOGGER = LoggerFactory.getLogger(WCSSecurityConnector.class);

    public static final URL MY_WSDL = WCSSecurityConnector.class.getClassLoader().getResource("wsdl/wcssecurity_service.wsdl");
    protected static final QName WCS_SECURITY_WSDL_QNAME = new QName("http://service.security.wcs.fortna.com/", "WCSSecurityService");

    /**
     * Duplicated from WCS Security, should move into wsdl definition
     */
    public enum LoginContext {
        FPC_CONTEXT("WCS Fortna Plus Controls Context"), // Pulls actions starting with "fpc."
        PPP_CONTEXT("PickPutPack Context"), // Pulls actions starting with "ppp."
        WEBUI_CONTEXT("WCS Web UI Context"), // OBSOLETE - pulls actions starting with "wcs." - WCSPortal/WCSReport (Liferay/Jasperserver)
        PORTAL_CONTEXT("WCS Portal Context"), // OBSOLETE - pulls actions starting with "portal." - WCSPortal/WCSReport
        DCMANAGER_CONTEXT("WCS DC Manager Context"), // OBSOLETE - pulls actions starting with "gui." - dcmanager
        RF_CONTEXT("RF Services Context");
        private final String desc;

        private LoginContext(String description) {
            this.desc = description;
        }
    }

    /**
     * Set the correct value of <soap:address location="https://localhost:8081/wcs-security-ejb/WCSSecurity"/>
     * Eg: https://192.168.13.14:8081/wcs-security-ejb/WCSSecurity
     * @param securityServiceUrl
     * @return
     */
    public static WCSSecurity getWCSSecurityService(String securityServiceUrl) {
        LOGGER.info("WSDL-path for wcssecurity: {}", MY_WSDL);
        WCSSecurityService wcsSecurityService = new WCSSecurityService(MY_WSDL, WCS_SECURITY_WSDL_QNAME);
        WCSSecurity _service = wcsSecurityService.getWCSSecurityPort();
        if (securityServiceUrl != null) {
            LOGGER.info("WCS Security URL: {}", securityServiceUrl);
            ((BindingProvider) _service).getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, securityServiceUrl);
        }
        return _service;
    }

}
