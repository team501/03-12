package com.fortna.wes.auth;

import com.fortna.wes.auth.model.AuthenResponseData;
import com.fortna.wes.auth.service.AuthenticationService;
import com.fortna.wes.auth.service.AuthenticationServiceMockImpl;
import com.fortna.wes.auth.service.AuthenticationServiceSOAPImpl;
import com.typesafe.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Objects;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class WESAuthenticationWCSSecurity {

    private static final Logger LOGGER = LoggerFactory.getLogger(WESAuthenticationWCSSecurity.class);
    private static final WESAuthenticationWCSSecurity INSTANCE = new WESAuthenticationWCSSecurity();

    private static final String AUTHENTICATION_TYPE_SOAP = "SOAP";
    private static final String AUTHENTICATION_TYPE_HTTP = "HTTP";

    private static final String CONFIG_WES_AUTHENTICATION_ROOT = "wes.authentication.wscsecurity";
    private static final String CONFIG_AUTHENTICATION_TYPE = "type";
    private static final String CONFIG_AUTHENTICATION_URL = "url";
    private static final String CONFIG_AUTHENTICATION_CONTEXT = "context";

    private static final String CONFIG_AUTHENTICATION_MOCK = "mock";
    private static final String CONFIG_AUTHENTICATION_MOCK_ENABLED = "enabled";
    private static final String CONFIG_AUTHENTICATION_MOCK_PERMISSIONS = "assignedPermissions";
    private static final String CONFIG_AUTHENTICATION_MOCK_ROLES = "assignedRoles";

    private AuthenticationService authenticationService;

    private WESAuthenticationWCSSecurity() {
    }

    public static WESAuthenticationWCSSecurity instance() {
        return INSTANCE;
    }

    public void init(Config config) {
        if (Objects.isNull(config) || !config.hasPath(CONFIG_WES_AUTHENTICATION_ROOT)) {
            throw new RuntimeException("Missing configuration path: " + CONFIG_WES_AUTHENTICATION_ROOT);
        } else {
            final Config authenConfig = config.getConfig(CONFIG_WES_AUTHENTICATION_ROOT);
            LOGGER.info("Load authentication configuration: {}", authenConfig);
            final AuthenticationConfig configObj = new AuthenticationConfig();
            if (authenConfig.hasPath(CONFIG_AUTHENTICATION_TYPE)) {
                configObj.setType(authenConfig.getString(CONFIG_AUTHENTICATION_TYPE));
            } else {
                throw new RuntimeException("Missing configuration path: " + CONFIG_AUTHENTICATION_TYPE);
            }
            if (authenConfig.hasPath(CONFIG_AUTHENTICATION_URL)) {
                configObj.setUrl(authenConfig.getString(CONFIG_AUTHENTICATION_URL));
            } else {
                throw new RuntimeException("Missing configuration path: " + CONFIG_AUTHENTICATION_URL);
            }
            if (authenConfig.hasPath(CONFIG_AUTHENTICATION_CONTEXT)) {
                configObj.setContext(authenConfig.getString(CONFIG_AUTHENTICATION_CONTEXT));
            } else if (AUTHENTICATION_TYPE_SOAP.equalsIgnoreCase(configObj.getType())) {
                throw new RuntimeException("Missing configuration path: " + CONFIG_AUTHENTICATION_CONTEXT);
            }
            if (authenConfig.hasPath(CONFIG_AUTHENTICATION_MOCK)) {
                final Config mockConfig = authenConfig.getConfig(CONFIG_AUTHENTICATION_MOCK);
                if (mockConfig.hasPath(CONFIG_AUTHENTICATION_MOCK_ENABLED)
                        && mockConfig.getBoolean(CONFIG_AUTHENTICATION_MOCK_ENABLED)) {
                    configObj.setMockEnabled(true);
                    if (mockConfig.hasPath(CONFIG_AUTHENTICATION_MOCK_PERMISSIONS)) {
                        configObj.setAssignedPermissions(mockConfig.getStringList(CONFIG_AUTHENTICATION_MOCK_PERMISSIONS));
                    }
                    if (mockConfig.hasPath(CONFIG_AUTHENTICATION_MOCK_ROLES)) {
                        configObj.setAssignedRoles(mockConfig.getStringList(CONFIG_AUTHENTICATION_MOCK_ROLES));
                    }
                }
            }
            LOGGER.info("Initialize WESAuthenticationWCSSecurity with type {}", configObj.getType());
            if (AUTHENTICATION_TYPE_SOAP.equalsIgnoreCase(configObj.getType())) {
                if (configObj.isMockEnabled()) {
                    authenticationService = new AuthenticationServiceMockImpl(
                            configObj.getAssignedPermissions(), configObj.getAssignedRoles());
                } else {
                    authenticationService = new AuthenticationServiceSOAPImpl(configObj.getUrl(), configObj.getContext());
                }
            } else {
                throw new UnsupportedOperationException("Not support type of authentication: " + configObj.getType());
            }
        }
    }

    public AuthenResponseData login(String username, String password) {
        return authenticationService.login(username, password);
    }

    public AuthenResponseData loginBadge(String badge) {
        return authenticationService.loginBadge(badge);
    }

    public AuthenResponseData logout(String username) {
        return authenticationService.logout(username);
    }

    public AuthenResponseData logoutBadge(String badge) {
        return authenticationService.logoutBadge(badge);
    }

    private static class AuthenticationConfig {
        private String type;
        private String url;
        private String context;

        private boolean mockEnabled;
        private List<String> assignedPermissions;
        private List<String> assignedRoles;

        public AuthenticationConfig() {
        }

        public AuthenticationConfig(String type, String url, String context) {
            this.type = type;
            this.url = url;
            this.context = context;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getContext() {
            return context;
        }

        public void setContext(String context) {
            this.context = context;
        }

        public boolean isMockEnabled() {
            return mockEnabled;
        }

        public void setMockEnabled(boolean mockEnabled) {
            this.mockEnabled = mockEnabled;
        }

        public List<String> getAssignedPermissions() {
            return assignedPermissions;
        }

        public void setAssignedPermissions(List<String> assignedPermissions) {
            this.assignedPermissions = assignedPermissions;
        }

        public List<String> getAssignedRoles() {
            return assignedRoles;
        }

        public void setAssignedRoles(List<String> assignedRoles) {
            this.assignedRoles = assignedRoles;
        }
    }
}
