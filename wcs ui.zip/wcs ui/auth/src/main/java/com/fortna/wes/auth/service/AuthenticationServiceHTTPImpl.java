package com.fortna.wes.auth.service;

import com.fortna.wes.auth.model.AuthenResponseData;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class AuthenticationServiceHTTPImpl implements AuthenticationService {

    @Override
    public AuthenResponseData login(String username, String password) {
        return authen(username);
    }

    @Override
    public AuthenResponseData loginBadge(String badge) {
        return authen(badge);
    }

    @Override
    public AuthenResponseData logout(String username) {
        return authen(username);
    }

    @Override
    public AuthenResponseData logoutBadge(String badge) {
        return authen(badge);
    }

    private AuthenResponseData authen(String usernameOrBadge) {
        return null;
    }
}
