package com.fortna.wes.auth.service;

import com.fortna.wcs.security.service.LoginBadgeReturn;
import com.fortna.wcs.security.service.LoginReturn;
import com.fortna.wes.auth.model.AuthenResponseData;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public interface AuthenticationService {

    AuthenResponseData login(String username, String password);
    AuthenResponseData loginBadge(String badge);

    AuthenResponseData logout(String username);
    AuthenResponseData logoutBadge(String badge);

    default AuthenResponseData convert2AuthenResponseData(LoginBadgeReturn loginResult) {
        AuthenResponseData retVal = new AuthenResponseData();
        retVal.setAssignedPermissions(loginResult.getAssignedPermissions());
        retVal.setAssignedRoles(loginResult.getAssignedRoles());
        retVal.setBadgeId(loginResult.getBadgeId());
        retVal.setLocaleCode(loginResult.getLocaleCode());
        retVal.setName(loginResult.getName());
        retVal.setSessionId(String.valueOf(loginResult.getSessionId()));
        retVal.setSessionTimeout(loginResult.getSessionTimeout());
        retVal.setStatusId(loginResult.getStatusId());
        retVal.setStatusMessage(loginResult.getStatusMessage());
        retVal.setUserName(loginResult.getUserName());
        return retVal;
    }

    default AuthenResponseData convert2AuthenResponseData(LoginReturn loginResult) {
        if (loginResult == null) {
            return null;
        }
        AuthenResponseData retVal = new AuthenResponseData();
        retVal.setAssignedPermissions(loginResult.getAssignedPermissions());
        retVal.setAssignedRoles(loginResult.getAssignedRoles());
        retVal.setBadgeId(loginResult.getBadgeId());
        retVal.setLocaleCode(loginResult.getLocaleCode());
        retVal.setName(loginResult.getName());
        retVal.setSessionId(String.valueOf(loginResult.getSessionId()));
        retVal.setSessionTimeout(loginResult.getSessionTimeout());
        retVal.setStatusId(loginResult.getStatusId());
        retVal.setStatusMessage(loginResult.getStatusMessage());
        retVal.setUserName(loginResult.getUserName());
        return retVal;
    }
}
