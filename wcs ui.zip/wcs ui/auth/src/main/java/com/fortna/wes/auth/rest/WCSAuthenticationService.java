package com.fortna.wes.auth.rest;

import org.springframework.stereotype.Service;

import com.fortna.wes.auth.WESAuthenticationWCSSecurity;
import com.fortna.wes.auth.model.AuthenResponseData;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;


@Service
public class WCSAuthenticationService {
	
	private Config defaultConfig = ConfigFactory.parseResources("default.conf");
	
	public AuthenResponseData sendRequest(UserLogin loginDetails) {
		WESAuthenticationWCSSecurity.instance().init(defaultConfig);
		final AuthenResponseData authenResData = WESAuthenticationWCSSecurity.instance().login(loginDetails.getLoginName(), loginDetails.getPassword());		
		return authenResData;
	}
}
