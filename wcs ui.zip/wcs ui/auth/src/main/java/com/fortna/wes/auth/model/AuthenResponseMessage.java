package com.fortna.wes.auth.model;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class AuthenResponseMessage {

    public static final String LOGIN_SUCCESS = "LOGIN.NEW.SUCCESSFUL";

    public static final String LOGOUT_SUCCESS = "LOGOUT.SUCCESSFUL";
    public static final String LOGOUT_NOT_LOGIN = "LOGOUT.NOT_LOGIN_YET";

    public static final String VERIFY_SESSION_SUCCESS = "CHECK_SESSION.TRUE";
    public static final String VERIFY_SESSION_FAILURE = "CHECK_SESSION.FALSE";

    private AuthenResponseMessage() {
    }
}
