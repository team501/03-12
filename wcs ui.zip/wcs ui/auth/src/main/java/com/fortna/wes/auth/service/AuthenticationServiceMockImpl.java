package com.fortna.wes.auth.service;

import com.fortna.wes.auth.model.AuthenResponseCode;
import com.fortna.wes.auth.model.AuthenResponseData;
import com.fortna.wes.auth.model.AuthenResponseMessage;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Dat Dao <datdao@fortna.com>
 * @since 12-Dec-18.
 */
public class AuthenticationServiceMockImpl implements AuthenticationService {

    protected static final DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    private List<String> assignedPermissions;
    private List<String> assignedRoles;

    public AuthenticationServiceMockImpl(List<String> assignedPermissions, List<String> assignedRoles) {
        this.assignedPermissions = assignedPermissions;
        this.assignedRoles = assignedRoles;
    }

    @Override
    public AuthenResponseData login(String username, String password) {
        final AuthenResponseData authenResponseData = authen(username);
        if (authenResponseData.getStatusId() == AuthenResponseCode.AUTHEN_SUCCESS) {
            authenResponseData.setStatusMessage(AuthenResponseMessage.LOGIN_SUCCESS);
        } else {
            authenResponseData.setStatusMessage(AuthenResponseMessage.VERIFY_SESSION_FAILURE);
        }
        return authenResponseData;
    }

    @Override
    public AuthenResponseData loginBadge(String badge) {
        final AuthenResponseData authenResponseData = authen(badge);
        if (authenResponseData.getStatusId() == AuthenResponseCode.AUTHEN_SUCCESS) {
            authenResponseData.setStatusMessage(AuthenResponseMessage.LOGIN_SUCCESS);
        } else {
            authenResponseData.setStatusMessage(AuthenResponseMessage.VERIFY_SESSION_FAILURE);
        }
        return authenResponseData;
    }

    @Override
    public AuthenResponseData logout(String username) {
        final AuthenResponseData authenResponseData = authen(username);
        if (authenResponseData.getStatusId() == AuthenResponseCode.AUTHEN_SUCCESS) {
            authenResponseData.setStatusMessage(AuthenResponseMessage.LOGOUT_SUCCESS);
        } else {
            authenResponseData.setStatusMessage(AuthenResponseMessage.VERIFY_SESSION_FAILURE);
        }
        return authenResponseData;
    }

    @Override
    public AuthenResponseData logoutBadge(String badge) {
        final AuthenResponseData authenResponseData = authen(badge);
        if (authenResponseData.getStatusId() == AuthenResponseCode.AUTHEN_SUCCESS) {
            authenResponseData.setStatusMessage(AuthenResponseMessage.LOGOUT_SUCCESS);
        } else {
            authenResponseData.setStatusMessage(AuthenResponseMessage.VERIFY_SESSION_FAILURE);
        }
        return authenResponseData;
    }

    private AuthenResponseData authen(String usernameOrBadge) {
        AuthenResponseData resData = new AuthenResponseData();
        if (usernameOrBadge.length() < 5) {
            resData.setStatusId(AuthenResponseCode.AUTHEN_FAILURE);
        } else {
            resData.setStatusId(AuthenResponseCode.AUTHEN_SUCCESS);
        }
        resData.setBadgeId(usernameOrBadge);
        resData.setUserName(usernameOrBadge);
        resData.setName(usernameOrBadge);
        resData.setLoginTime(dateFormat.format(Calendar.getInstance().getTime()));
        resData.setSessionId(UUID.randomUUID().toString());
        resData.setAssignedPermissions(getAssignedPermissions());
        resData.setAssignedRoles(getAssignedRoles());
        resData.setSessionTimeout(3600L);
        return resData;
    }

    protected List<String> getAssignedPermissions() {
        if (Objects.isNull(assignedPermissions)) return Collections.emptyList();
        return assignedPermissions;
    }

    protected List<String> getAssignedRoles() {
        if (Objects.isNull(assignedRoles)) return Collections.emptyList();
        return assignedRoles;
    }
}
